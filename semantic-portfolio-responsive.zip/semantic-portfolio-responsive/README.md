# Advanced CSS3 & Responsive Portfolio

- CSS Grid for hero, project cards, about and contact page layouts.
- Flexbox for navigation, action buttons, header controls and footer.
- Mobile-first responsive breakpoints for tablet and desktop.
- CSS custom properties power light/dark themes.
- Accessible theme toggle remembers the choice in local storage.
- Keyboard focus styles, skip link, semantic landmarks, labelled form controls and reduced-motion support.

## Run
Extract the ZIP, open the folder in VS Code, then open `index.html` with Live Server.

## Before submission
Replace example email/social URLs and canonical `example.com` URLs. Connect the contact form to a real backend/form service. Test at 320px, 375px, 768px, 1024px and 1440px. Run Lighthouse on the deployed site; a perfect score depends on final content and hosting.
