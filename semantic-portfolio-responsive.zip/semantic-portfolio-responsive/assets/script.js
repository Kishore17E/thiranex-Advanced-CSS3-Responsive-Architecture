'use strict';
const root = document.documentElement;
const toggle = document.querySelector('[data-theme-toggle]');
const saved = localStorage.getItem('portfolio-theme');
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
root.dataset.theme = saved || (prefersDark ? 'dark' : 'light');
function syncThemeButton() {
  if (!toggle) return;
  const dark = root.dataset.theme === 'dark';
  toggle.textContent = dark ? '☀' : '☾';
  toggle.setAttribute('aria-pressed', String(dark));
  toggle.setAttribute('aria-label', dark ? 'Switch to light theme' : 'Switch to dark theme');
}
syncThemeButton();
toggle?.addEventListener('click', () => {
  root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('portfolio-theme', root.dataset.theme);
  syncThemeButton();
});
document.querySelectorAll('[data-current-year]').forEach(el => el.textContent = String(new Date().getFullYear()));
